﻿using CsvHelper;
using Microsoft.Win32;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Formats.Asn1;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Blankfilenotifier
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window , INotifyPropertyChanged
    {
        public MainWindow()
        {
            InitializeComponent();
            DefaultFileSize = 5;
            this.DataContext = this;
        }

        private long _defaultFileSize;

        public long DefaultFileSize
        {
            get { return _defaultFileSize; }
            set { _defaultFileSize = value;
                FileDetailsDTO.DefaultFileSize=value;
            OnPropertyChanged(nameof(DefaultFileSize)); 
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public ObservableCollection<FileDetailsDTO> FlatFileList = new ObservableCollection<FileDetailsDTO>();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FlatFileList?.Clear();
            var dialog = new OpenFolderDialog()
            {
                Title = "Select folder",
                InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                Multiselect = true
            };

            string folderName = "";
            if (dialog.ShowDialog() == true)
            {
                folderName = dialog.FolderName;
            }

            Dispatcher.BeginInvoke(new Action(() =>
            {
                string[] entries = Directory.GetFileSystemEntries(folderName, "*", SearchOption.AllDirectories);
                List<string> filesPaths = entries.ToList();

                foreach (string file in filesPaths)
                {
                    if (System.IO.File.Exists(file))
                    {
                        FileInfo fs = new FileInfo(file);
                        long filesize = fs.Length / 1024;
                        FlatFileList?.Add(new FileDetailsDTO { FileName = file, FileSize = filesize ,FileExtension = System.IO.Path.GetExtension(file) });
                        OnPropertyChanged(nameof(FlatFileList));

                    }
                }
                datagridview.ItemsSource = FlatFileList;
                var currentDirectory = System.IO.Directory.GetCurrentDirectory();
                // Write to a file.
                using (var writer = new StreamWriter(currentDirectory + "\\data.csv")) 
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    csv.WriteRecords(FlatFileList);
                }

                


            }));
            
            


        }


    }
}