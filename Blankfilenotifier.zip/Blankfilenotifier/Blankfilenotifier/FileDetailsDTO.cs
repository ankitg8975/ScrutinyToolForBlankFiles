﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blankfilenotifier
{
    public class FileDetailsDTO:INotifyPropertyChanged
    {
        private bool _isFileTooSmall;

        public bool IsFileTooSmall
        {
            get { return _isFileTooSmall; }
            set { _isFileTooSmall = value; }
        }

        public static long DefaultFileSize = 5;

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        private string _fileName=string.Empty;

		public string FileName
		{
			get { return _fileName; }
			set { _fileName = value;
            OnPropertyChanged(nameof(FileName));    
            }
		}



        private string _fullPath = string.Empty;

        public string FullPath
        {
            get { return _fullPath; }
            set { _fullPath = value;
               
                OnPropertyChanged(nameof(FullPath));
            }
        }

        private string _fileExtension = string.Empty;

        public string FileExtension
        {
            get { return _fileExtension; }
            set
            {
                _fileExtension = value;

                OnPropertyChanged(nameof(FullPath));
            }
        }

        private long _fileSize = 0;

        public long FileSize
        {
            get { return _fileSize; }
            set { _fileSize = value;
                if (value <= DefaultFileSize)
                {
                    IsFileTooSmall = true; 
                    OnPropertyChanged(nameof(FileSize));
                }

                OnPropertyChanged(nameof(FileSize));
            }
        }

       

    }
}
